"""Multi-language support for alerts (EN / HE / FR)."""

TRANSLATIONS = {
    "en": {
        "bot_started": "🚀 Market Intelligence Bot Started!\n\n🔍 Status: Active\n⏰ Frequency: Every {interval} min\n📊 Sources: Polymarket, Kalshi, RSS\n🎯 Alert threshold: {threshold}+ bps\n🌐 Languages: EN, HE, FR",
        "gap_alert_title": "🔔 GAP ALERT — {market_name}",
        "gap_alert_body": (
            "📊 Market: {market_name}\n"
            "🏷️ Category: {category}\n\n"
            "Polymarket: {poly_price}%\n"
            "Kalshi: {kalshi_price}%\n"
            "📐 Gap: {gap_bps} bps\n"
            "📈 Direction: {direction}\n\n"
            "🔗 Poly: {poly_url}\n"
            "🔗 Kalshi: {kalshi_url}"
        ),
        "rss_alert_title": "📰 {feed_name} — New Update",
        "rss_alert_body": "📌 {title}\n\n{summary}\n\n🔗 {link}",
        "big_move_title": "⚡ BIG MOVE — {market_name}",
        "big_move_body": (
            "📊 {market_name}\n"
            "🏷️ Category: {category}\n"
            "Source: {source}\n\n"
            "Before: {old_price}% → Now: {new_price}%\n"
            "📐 Move: {delta_bps} bps\n"
            "⏱️ Timeframe: {timeframe}\n\n"
            "🔗 {url}"
        ),
        "heartbeat": "💓 Bot alive — {timestamp}\nMarkets tracked: {market_count}\nFeeds monitored: {feed_count}",
        "error": "⚠️ Error: {error_msg}",
        "no_alerts": "✅ Scan complete — no significant gaps or moves detected.",
    },
    "he": {
        "bot_started": "🚀 בוט מודיעין שווקים הופעל!\n\n🔍 מצב: פעיל\n⏰ תדירות: כל {interval} דקות\n📊 מקורות: Polymarket, Kalshi, RSS\n🎯 סף התראה: {threshold}+ נ\"ב\n🌐 שפות: EN, HE, FR",
        "gap_alert_title": "🔔 התראת פער — {market_name}",
        "gap_alert_body": (
            "📊 שוק: {market_name}\n"
            "🏷️ קטגוריה: {category}\n\n"
            "Polymarket: {poly_price}%\n"
            "Kalshi: {kalshi_price}%\n"
            "📐 פער: {gap_bps} נ\"ב\n"
            "📈 כיוון: {direction}\n\n"
            "🔗 Poly: {poly_url}\n"
            "🔗 Kalshi: {kalshi_url}"
        ),
        "rss_alert_title": "📰 {feed_name} — עדכון חדש",
        "rss_alert_body": "📌 {title}\n\n{summary}\n\n🔗 {link}",
        "big_move_title": "⚡ תנועה גדולה — {market_name}",
        "big_move_body": (
            "📊 {market_name}\n"
            "🏷️ קטגוריה: {category}\n"
            "מקור: {source}\n\n"
            "לפני: {old_price}% → עכשיו: {new_price}%\n"
            "📐 תנועה: {delta_bps} נ\"ב\n"
            "⏱️ טווח זמן: {timeframe}\n\n"
            "🔗 {url}"
        ),
        "heartbeat": "💓 הבוט פעיל — {timestamp}\nשווקים במעקב: {market_count}\nפידים במעקב: {feed_count}",
        "error": "⚠️ שגיאה: {error_msg}",
        "no_alerts": "✅ סריקה הושלמה — לא זוהו פערים או תנועות משמעותיים.",
    },
    "fr": {
        "bot_started": "🚀 Bot Intelligence Marchés Activé!\n\n🔍 Statut: Actif\n⏰ Fréquence: Toutes les {interval} min\n📊 Sources: Polymarket, Kalshi, RSS\n🎯 Seuil d'alerte: {threshold}+ pdb\n🌐 Langues: EN, HE, FR",
        "gap_alert_title": "🔔 ALERTE ÉCART — {market_name}",
        "gap_alert_body": (
            "📊 Marché: {market_name}\n"
            "🏷️ Catégorie: {category}\n\n"
            "Polymarket: {poly_price}%\n"
            "Kalshi: {kalshi_price}%\n"
            "📐 Écart: {gap_bps} pdb\n"
            "📈 Direction: {direction}\n\n"
            "🔗 Poly: {poly_url}\n"
            "🔗 Kalshi: {kalshi_url}"
        ),
        "rss_alert_title": "📰 {feed_name} — Nouvelle mise à jour",
        "rss_alert_body": "📌 {title}\n\n{summary}\n\n🔗 {link}",
        "big_move_title": "⚡ MOUVEMENT IMPORTANT — {market_name}",
        "big_move_body": (
            "📊 {market_name}\n"
            "🏷️ Catégorie: {category}\n"
            "Source: {source}\n\n"
            "Avant: {old_price}% → Maintenant: {new_price}%\n"
            "📐 Mouvement: {delta_bps} pdb\n"
            "⏱️ Période: {timeframe}\n\n"
            "🔗 {url}"
        ),
        "heartbeat": "💓 Bot en vie — {timestamp}\nMarchés suivis: {market_count}\nFlux surveillés: {feed_count}",
        "error": "⚠️ Erreur: {error_msg}",
        "no_alerts": "✅ Scan terminé — aucun écart ou mouvement significatif détecté.",
    },
}


def t(key: str, lang: str = "en", **kwargs) -> str:
    """Get translated string with formatting."""
    template = TRANSLATIONS.get(lang, TRANSLATIONS["en"]).get(key, key)
    try:
        return template.format(**kwargs)
    except KeyError:
        return template
