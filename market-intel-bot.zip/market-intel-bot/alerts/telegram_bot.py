"""Telegram bot for sending alerts."""

import asyncio
import logging
from typing import Optional

from telegram import Bot
from telegram.constants import ParseMode
from telegram.error import TelegramError, RetryAfter

from config import Config
from i18n.translations import t

logger = logging.getLogger(__name__)

# Rate limit: max 30 messages per second to a chat
SEND_DELAY = 0.5  # seconds between messages


class TelegramNotifier:
    def __init__(self):
        self.bot = Bot(token=Config.TELEGRAM_BOT_TOKEN)
        self.chat_id = Config.TELEGRAM_CHAT_ID
        self.languages = Config.LANGUAGES

    async def send(self, text: str, parse_mode: Optional[str] = None) -> bool:
        """Send a message to the configured chat."""
        try:
            await self.bot.send_message(
                chat_id=self.chat_id,
                text=text,
                parse_mode=parse_mode,
                disable_web_page_preview=True,
            )
            return True
        except RetryAfter as e:
            logger.warning(f"Rate limited, retrying in {e.retry_after}s")
            await asyncio.sleep(e.retry_after)
            return await self.send(text, parse_mode)
        except TelegramError as e:
            logger.error(f"Telegram send error: {e}")
            return False

    async def send_multilingual(self, key: str, **kwargs) -> None:
        """Send a message in all configured languages."""
        for lang in self.languages:
            msg = t(key, lang=lang, **kwargs)
            await self.send(msg)
            await asyncio.sleep(SEND_DELAY)

    async def send_startup(self) -> None:
        """Send bot startup notification."""
        for lang in self.languages:
            msg = t(
                "bot_started",
                lang=lang,
                interval=Config.CHECK_INTERVAL_MINUTES,
                threshold=Config.ALERT_THRESHOLD_BPS,
            )
            await self.send(msg)
            await asyncio.sleep(SEND_DELAY)

    async def send_gap_alert(self, alert) -> None:
        """Send a gap alert in all languages."""
        for lang in self.languages:
            title = t("gap_alert_title", lang=lang, market_name=alert.market_name)
            body = t(
                "gap_alert_body",
                lang=lang,
                market_name=alert.market_name,
                category=alert.category,
                poly_price=alert.poly_price,
                kalshi_price=alert.kalshi_price,
                gap_bps=alert.gap_bps,
                direction=alert.direction,
                poly_url=alert.poly_url,
                kalshi_url=alert.kalshi_url,
            )
            await self.send(f"{title}\n\n{body}")
            await asyncio.sleep(SEND_DELAY)

    async def send_big_move_alert(self, alert) -> None:
        """Send a big move alert in all languages."""
        for lang in self.languages:
            title = t("big_move_title", lang=lang, market_name=alert.market_name)
            body = t(
                "big_move_body",
                lang=lang,
                market_name=alert.market_name,
                category=alert.category,
                source=alert.source,
                old_price=alert.old_price,
                new_price=alert.new_price,
                delta_bps=alert.delta_bps,
                timeframe=alert.timeframe,
                url=alert.url,
            )
            await self.send(f"{title}\n\n{body}")
            await asyncio.sleep(SEND_DELAY)

    async def send_rss_alert(self, item) -> None:
        """Send an RSS news alert in all languages."""
        for lang in self.languages:
            title = t("rss_alert_title", lang=lang, feed_name=item.feed_name)
            body = t(
                "rss_alert_body",
                lang=lang,
                title=item.title,
                summary=item.summary[:300],
                link=item.link,
            )
            await self.send(f"{title}\n\n{body}")
            await asyncio.sleep(SEND_DELAY)

    async def send_heartbeat(self, market_count: int, feed_count: int) -> None:
        """Send a heartbeat / alive message."""
        from datetime import datetime, timezone
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M UTC")
        # Heartbeat only in first language to reduce noise
        msg = t(
            "heartbeat",
            lang=self.languages[0],
            timestamp=ts,
            market_count=market_count,
            feed_count=feed_count,
        )
        await self.send(msg)

    async def send_no_alerts(self) -> None:
        """Send a 'no alerts' message (only in first language)."""
        msg = t("no_alerts", lang=self.languages[0])
        await self.send(msg)

    async def send_error(self, error_msg: str) -> None:
        """Send an error notification."""
        msg = t("error", lang=self.languages[0], error_msg=str(error_msg)[:500])
        await self.send(msg)
